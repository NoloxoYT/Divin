import { Groq } from 'groq-sdk';

// API keys pool for rotation
const API_KEYS = [
  process.env.GROQ_API_KEY_1,
  process.env.GROQ_API_KEY_2,
  process.env.GROQ_API_KEY_3,
  process.env.GROQ_API_KEY_4,
  process.env.GROQ_API_KEY_5,
].filter(Boolean) as string[];

let currentKeyIndex = 0;

function getNextApiKey(): string {
  if (API_KEYS.length === 0) {
    throw new Error("Aucune clé API Groq disponible");
  }
  const key = API_KEYS[currentKeyIndex];
  currentKeyIndex = (currentKeyIndex + 1) % API_KEYS.length;
  return key;
}

export interface AIMessage {
  role: "system" | "user" | "assistant";
  content: string;
  timestamp?: number;
}

const PLANNING_SYSTEM_PROMPT = `Rôle : Assistant spécialisé dans la planification et l'organisation de projets de développement logiciel.
Mission :

Analyser les demandes utilisateur concernant la conception, l'architecture, les étapes et la gestion du projet.

Proposer des plans détaillés, découpage en tâches, estimation de temps, risques potentiels.

Répondre uniquement aux questions liées à la planification, conception ou validation avant codage.

Interdiction totale de générer du code ou des fragments de code.

Respecter la limite de 25 requêtes par jour.

Style : Clair, synthétique, pragmatique, orienté productivité.

Réponds toujours en Markdown, même pour les listes, explications, ou exemples.`;

const DEVELOPMENT_SYSTEM_PROMPT = `Rôle : Assistant expert en génération de code, optimisation, correction d'erreurs et création de fonctionnalités.
Mission :

Recevoir des spécifications validées, traduire en code source fiable, propre et maintenable.

Proposer des optimisations et améliorations techniques.

Corriger les erreurs et bugs dans le code fourni.

Répondre uniquement aux questions liées à l'écriture, optimisation et correction de code.

Respecter la limite de 50 requêtes par jour.

Style : Technique, détaillé, précis, avec des explications quand nécessaire.

Réponds toujours en Markdown, même pour les listes, explications, ou exemples.`;

export class AIService {
  async sendMessage(
    messages: AIMessage[],
    phase: "planning" | "development",
    stream: boolean = false
  ): Promise<string> {
    const model = phase === "planning" 
      ? "llama-3.1-8b-instant" 
      : "deepseek-r1-distill-llama-70b";
      
    const temperature = phase === "planning" ? 1 : 0.6;
    const maxTokens = phase === "planning" ? 1024 : 4096;
    const topP = phase === "planning" ? 1 : 0.95;
    
    const systemPrompt = phase === "planning" ? PLANNING_SYSTEM_PROMPT : DEVELOPMENT_SYSTEM_PROMPT;

    const formattedMessages = [
      { role: "system" as const, content: systemPrompt },
      ...messages.map(msg => ({
        role: msg.role as "user" | "assistant",
        content: msg.content
      }))
    ];

    // Try up to 3 different API keys before failing
    for (let attempt = 0; attempt < 3; attempt++) {
      try {
        const groq = new Groq({
          apiKey: getNextApiKey(),
        });
        
        const completion = await groq.chat.completions.create({
          messages: formattedMessages,
          model,
          temperature,
          max_completion_tokens: maxTokens,
          top_p: topP,
          stream: false,
          stop: null,
        });

        return completion.choices[0]?.message?.content || "Désolé, je n'ai pas pu générer une réponse.";
      } catch (error) {
        console.error(`AI Service Error (attempt ${attempt + 1}):`, error);
        
        // If it's an auth error, try next key
        if (error instanceof Error && (error.message.includes('401') || error.message.includes('invalid_api_key'))) {
          continue;
        }
        // For other errors, break immediately
        break;
      }
    }
    
    throw new Error("Échec de la communication avec le service IA. Veuillez réessayer.");
  }

  async transferPlanToDevelopment(planningMessages: AIMessage[]): Promise<string> {
    const lastPlanMessage = planningMessages
      .filter(msg => msg.role === "assistant")
      .pop();

    if (!lastPlanMessage) {
      return "No approved plan found to transfer to development phase.";
    }

    const transferPrompt = `Basé sur le plan de projet approuvé suivant, je suis maintenant prêt à commencer la phase de développement. Veuillez prendre connaissance du plan et fournir des conseils sur la façon de commencer l'implémentation:

${lastPlanMessage.content}

Commençons à coder !`;

    return await this.sendMessage(
      [{ role: "user", content: transferPrompt }],
      "development"
    );
  }
}

export const aiService = new AIService();
