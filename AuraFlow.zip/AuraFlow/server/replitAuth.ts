import * as client from "openid-client";
import { Strategy, type VerifyFunction } from "openid-client/passport";

import passport from "passport";
import session from "express-session";
import type { Express, RequestHandler } from "express";
import memoize from "memoizee";
import connectPg from "connect-pg-simple";
import { storage } from "./storage";

// AUTH REPLIT DÉSACTIVÉE POUR DEV LOCAL
export async function setupAuth(app: any) {
  // Pas d'authentification en local
}

export function isAuthenticated(req: any, res: any, next: any) {
  // Vérifie vraiment l'authentification
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: "Not authenticated" });
}
