import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { aiService, type AIMessage } from "./aiService";
import { insertProjectSchema } from "@shared/schema";
import { z } from "zod";
import passport from "passport";
import { Strategy as GoogleStrategy } from "passport-google-oauth20";
import { Strategy as GitHubStrategy } from "passport-github2";
import session from "express-session";

// Configuration des stratégies (clés à renseigner dans le .env)
passport.use(new GoogleStrategy({
  clientID: process.env.GOOGLE_CLIENT_ID || "",
  clientSecret: process.env.GOOGLE_CLIENT_SECRET || "",
  callbackURL: "http://localhost:3000/api/auth/google/callback",
}, (accessToken, refreshToken, profile, done) => {
  return done(null, profile);
}));

passport.use(new GitHubStrategy({
  clientID: process.env.GITHUB_CLIENT_ID || "",
  clientSecret: process.env.GITHUB_CLIENT_SECRET || "",
  callbackURL: "http://localhost:3000/api/auth/github/callback",
}, (accessToken, refreshToken, profile, done) => {
  return done(null, profile);
}));

// Sérialisation/désérialisation utilisateur (simplifiée)
passport.serializeUser((user, done) => done(null, user));
passport.deserializeUser((obj, done) => done(null, obj));

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  app.use(session({
    secret: process.env.SESSION_SECRET || "dev_secret",
    resave: false,
    saveUninitialized: false,
    cookie: { secure: false }
  }));
  app.use(passport.initialize());
  app.use(passport.session());

  // --- Google ---
  app.get('/api/auth/google', passport.authenticate('google', { scope: ['profile', 'email'] }));
  app.get('/api/auth/google/callback', passport.authenticate('google', { failureRedirect: '/' }), (req, res) => {
    // Redirige vers la page d'accueil après connexion réussie
    res.redirect('/');
  });

  // --- GitHub ---
  app.get('/api/auth/github', passport.authenticate('github', { scope: ['user:email'] }));
  app.get('/api/auth/github/callback', passport.authenticate('github', { failureRedirect: '/' }), (req, res) => {
    // Redirige vers la page d'accueil après connexion réussie
    res.redirect('/');
  });

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      // Debug : log l'objet utilisateur
      console.log("User object:", req.user);
      
      // Retourne directement les infos utilisateur de Passport
      const userInfo = {
        id: req.user.id || req.user.sub || req.user.email,
        email: req.user.email || req.user.emails?.[0]?.value,
        name: req.user.displayName || req.user.name?.givenName || req.user.name,
        picture: req.user.picture || req.user.photos?.[0]?.value,
        provider: req.user.provider || 'google'
      };
      
      res.json(userInfo);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Project routes
  app.get('/api/projects', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id || req.user.sub || req.user.email;
      const projects = await storage.getUserProjects(userId);
      res.json(projects);
    } catch (error) {
      console.error("Error fetching projects:", error);
      res.status(500).json({ message: "Failed to fetch projects" });
    }
  });

  app.post('/api/projects', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id || req.user.sub || req.user.email;
      const projectData = insertProjectSchema.parse({ ...req.body, userId });
      const project = await storage.createProject(projectData);
      res.json(project);
    } catch (error) {
      console.error("Error creating project:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid project data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create project" });
      }
    }
  });

  app.get('/api/projects/:id', isAuthenticated, async (req: any, res) => {
    try {
      const projectId = req.params.id;
      const project = await storage.getProject(projectId);
      
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      // Ensure user owns the project
      const userId = req.user.id || req.user.sub || req.user.email;
      if (project.userId !== userId) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      res.json(project);
    } catch (error) {
      console.error("Error fetching project:", error);
      res.status(500).json({ message: "Failed to fetch project" });
    }
  });

  app.post('/api/projects/:id/approve-plan', isAuthenticated, async (req: any, res) => {
    try {
      const projectId = req.params.id;
      const project = await storage.getProject(projectId);
      
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      const userId = req.user.id || req.user.sub || req.user.email;
      if (project.userId !== userId) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      // Update project to development phase
      const updatedProject = await storage.approveProjectPlan(projectId);
      
      // Generate initial development message
      const planningMessages = (project.planningMessages as AIMessage[]) || [];
      const initialDevMessage = await aiService.transferPlanToDevelopment(planningMessages);
      
      const developmentMessages = [{
        role: "system" as const,
        content: "Plan approved. Switched to development phase.",
        timestamp: Date.now()
      }, {
        role: "assistant" as const,
        content: initialDevMessage,
        timestamp: Date.now()
      }];
      
      await storage.updateProjectMessages(projectId, "development", developmentMessages);
      
      res.json(updatedProject);
    } catch (error) {
      console.error("Error approving plan:", error);
      res.status(500).json({ message: "Failed to approve plan" });
    }
  });

  // Chat routes
  app.post('/api/chat', isAuthenticated, async (req: any, res) => {
    try {
      const { message, projectId, phase } = req.body;
      const userId = req.user.claims.sub;
      
      if (!message || !projectId || !phase) {
        return res.status(400).json({ message: "Missing required fields" });
      }
      
      const project = await storage.getProject(projectId);
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      if (project.userId !== userId) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      // Check API limits
      const today = new Date().toISOString().split('T')[0];
      const usage = await storage.getApiUsage(userId, today);
      
      const planningLimit = 25;
      const developmentLimit = 50;
      const currentUsage = phase === "planning" ? (usage?.planningRequests || 0) : (usage?.developmentRequests || 0);
      const limit = phase === "planning" ? planningLimit : developmentLimit;
      
      if (currentUsage >= limit) {
        return res.status(429).json({ 
          message: `Daily limit reached for ${phase} AI (${currentUsage}/${limit})` 
        });
      }
      
      // Get existing messages
      const existingMessages = (phase === "planning" ? project.planningMessages : project.developmentMessages) as AIMessage[] || [];
      
      // Add user message
      const userMessage: AIMessage = {
        role: "user",
        content: message,
        timestamp: Date.now()
      };
      
      const messagesForAI = [...existingMessages, userMessage];
      
      // Send to AI
      const aiResponse = await aiService.sendMessage(messagesForAI, phase);
      
      // Add AI response
      const aiMessage: AIMessage = {
        role: "assistant",
        content: aiResponse,
        timestamp: Date.now()
      };
      
      const updatedMessages = [...messagesForAI, aiMessage];
      
      // Update project with new messages
      await storage.updateProjectMessages(projectId, phase, updatedMessages);
      
      // Update API usage
      const usageUpdate = phase === "planning" 
        ? { planningRequests: currentUsage + 1 }
        : { developmentRequests: currentUsage + 1 };
      
      await storage.updateApiUsage(userId, today, usageUpdate);
      
      res.json({
        message: aiMessage,
        usage: {
          [phase]: currentUsage + 1,
          limit
        }
      });
      
    } catch (error) {
      console.error("Error in chat:", error);
      res.status(500).json({ message: "Failed to process chat message" });
    }
  });

  // API Usage routes
  app.get('/api/usage', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id || req.user.sub || req.user.email;
      const today = new Date().toISOString().split('T')[0];
      const usage = await storage.getApiUsage(userId, today);
      
      res.json({
        planning: {
          used: usage?.planningRequests || 0,
          limit: 25
        },
        development: {
          used: usage?.developmentRequests || 0,
          limit: 50
        }
      });
    } catch (error) {
      console.error("Error fetching usage:", error);
      res.status(500).json({ message: "Failed to fetch API usage" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
