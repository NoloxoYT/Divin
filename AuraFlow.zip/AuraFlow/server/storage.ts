import {
  users,
  projects,
  apiUsage,
  type User,
  type UpsertUser,
  type Project,
  type InsertProject,
  type ApiUsage,
  type InsertApiUsage,
} from "@shared/schema";
import { db } from "./db";
import { eq, and } from "drizzle-orm";

// Interface for storage operations
export interface IStorage {
  // User operations (IMPORTANT) these user operations are mandatory for Replit Auth.
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Project operations
  getProject(id: string): Promise<Project | undefined>;
  getUserProjects(userId: string): Promise<Project[]>;
  createProject(project: InsertProject): Promise<Project>;
  updateProject(id: string, updates: Partial<Project>): Promise<Project>;
  updateProjectPhase(id: string, phase: "planning" | "development"): Promise<Project>;
  updateProjectMessages(id: string, phase: "planning" | "development", messages: any[]): Promise<Project>;
  approveProjectPlan(id: string): Promise<Project>;
  
  // API Usage operations
  getApiUsage(userId: string, date: string): Promise<ApiUsage | undefined>;
  updateApiUsage(userId: string, date: string, updates: Partial<ApiUsage>): Promise<ApiUsage>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Project operations
  async getProject(id: string): Promise<Project | undefined> {
    const [project] = await db.select().from(projects).where(eq(projects.id, id));
    return project;
  }

  async getUserProjects(userId: string): Promise<Project[]> {
    return await db.select().from(projects).where(eq(projects.userId, userId));
  }

  async createProject(project: InsertProject): Promise<Project> {
    const [newProject] = await db.insert(projects).values(project).returning();
    return newProject;
  }

  async updateProject(id: string, updates: Partial<Project>): Promise<Project> {
    const [updatedProject] = await db
      .update(projects)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(projects.id, id))
      .returning();
    return updatedProject;
  }

  async updateProjectPhase(id: string, phase: "planning" | "development"): Promise<Project> {
    const [updatedProject] = await db
      .update(projects)
      .set({ currentPhase: phase, updatedAt: new Date() })
      .where(eq(projects.id, id))
      .returning();
    return updatedProject;
  }

  async updateProjectMessages(id: string, phase: "planning" | "development", messages: any[]): Promise<Project> {
    const field = phase === "planning" ? "planningMessages" : "developmentMessages";
    const [updatedProject] = await db
      .update(projects)
      .set({ [field]: messages, updatedAt: new Date() })
      .where(eq(projects.id, id))
      .returning();
    return updatedProject;
  }

  async approveProjectPlan(id: string): Promise<Project> {
    const [updatedProject] = await db
      .update(projects)
      .set({ 
        planApproved: true, 
        currentPhase: "development", 
        updatedAt: new Date() 
      })
      .where(eq(projects.id, id))
      .returning();
    return updatedProject;
  }

  // API Usage operations
  async getApiUsage(userId: string, date: string): Promise<ApiUsage | undefined> {
    const [usage] = await db
      .select()
      .from(apiUsage)
      .where(and(eq(apiUsage.userId, userId), eq(apiUsage.date, date)));
    return usage;
  }

  async updateApiUsage(userId: string, date: string, updates: Partial<ApiUsage>): Promise<ApiUsage> {
    const existing = await this.getApiUsage(userId, date);
    
    if (existing) {
      const [updated] = await db
        .update(apiUsage)
        .set({ ...updates, updatedAt: new Date() })
        .where(and(eq(apiUsage.userId, userId), eq(apiUsage.date, date)))
        .returning();
      return updated;
    } else {
      const [created] = await db
        .insert(apiUsage)
        .values({ userId, date, ...updates })
        .returning();
      return created;
    }
  }
}

export const storage = new DatabaseStorage();
