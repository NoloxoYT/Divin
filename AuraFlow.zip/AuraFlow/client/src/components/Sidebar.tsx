import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useProject } from "@/contexts/ProjectContext";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Bot, Plus, Settings, LogOut } from "lucide-react";
import type { Project } from "@shared/schema";

export default function Sidebar() {
  const { user } = useAuth();
  const { currentProject, setCurrentProject, projects, setProjects } = useProject();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [newProjectOpen, setNewProjectOpen] = useState(false);
  const [newProject, setNewProject] = useState({
    title: "",
    description: "",
    framework: "",
  });

  // Fetch API usage
  const { data: apiUsage } = useQuery({
    queryKey: ["/api/usage"],
    refetchInterval: 60000, // Refetch every minute
    retry: false,
  });

  // Create project mutation
  const createProjectMutation = useMutation({
    mutationFn: async (projectData: any) => {
      const response = await apiRequest("POST", "/api/projects", projectData);
      return response.json();
    },
    onSuccess: (project) => {
      setProjects([...projects, project]);
      setCurrentProject(project);
      setNewProjectOpen(false);
      setNewProject({ title: "", description: "", framework: "" });
      toast({
        title: "Project created",
        description: "Your new project has been created successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        alert("Seule la connexion OAuth (Google, GitHub, Apple) est disponible pour le moment.");
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create project. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleCreateProject = () => {
    if (!newProject.title.trim()) {
      toast({
        title: "Error",
        description: "Project title is required.",
        variant: "destructive",
      });
      return;
    }
    createProjectMutation.mutate(newProject);
  };

  const getProjectStatusColor = (project: Project) => {
    if (project.currentPhase === "planning") return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300";
    if (project.currentPhase === "development") return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300";
    return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300";
  };

  const getStatusText = (project: Project) => {
    return project.currentPhase === "planning" ? "Planning" : "Development";
  };

  return (
    <aside className="w-64 bg-sidebar border-r border-sidebar-border flex flex-col">
      {/* Logo & User Info */}
      <div className="p-4 border-b border-sidebar-border">
        <div className="flex items-center mb-4">
          <div className="w-8 h-8 bg-sidebar-primary rounded-lg flex items-center justify-center mr-3">
            <Bot className="w-4 h-4 text-sidebar-primary-foreground" />
          </div>
          <h1 className="text-lg font-semibold text-sidebar-foreground">AI Dev Workflow</h1>
        </div>
        
        {/* User Profile */}
        <div className="flex items-center">
          <Avatar className="w-8 h-8 mr-3">
            <AvatarImage src={user?.profileImageUrl} alt="User avatar" className="object-cover" />
            <AvatarFallback>
              {user?.firstName?.[0]}{user?.lastName?.[0]}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-sidebar-foreground truncate">
              {user?.firstName} {user?.lastName}
            </p>
            <p className="text-xs text-sidebar-foreground/60 truncate">
              {user?.email}
            </p>
          </div>
        </div>
      </div>

      {/* Project List */}
      <div className="flex-1 p-4 overflow-y-auto custom-scrollbar">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-medium text-sidebar-foreground/60 uppercase tracking-wider">Projects</h3>
          <Dialog open={newProjectOpen} onOpenChange={setNewProjectOpen}>
            <DialogTrigger asChild>
              <Button size="sm" variant="ghost" className="p-1 h-6 w-6">
                <Plus className="w-4 h-4" />
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New Project</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="title">Project Title</Label>
                  <Input
                    id="title"
                    value={newProject.title}
                    onChange={(e) => setNewProject({ ...newProject, title: e.target.value })}
                    placeholder="My Awesome App"
                  />
                </div>
                <div>
                  <Label htmlFor="description">Description (Optional)</Label>
                  <Input
                    id="description"
                    value={newProject.description}
                    onChange={(e) => setNewProject({ ...newProject, description: e.target.value })}
                    placeholder="Brief description of your project"
                  />
                </div>
                <div>
                  <Label htmlFor="framework">Framework (Optional)</Label>
                  <Select value={newProject.framework} onValueChange={(value) => setNewProject({ ...newProject, framework: value })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select framework" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="react-native">React Native</SelectItem>
                      <SelectItem value="flutter">Flutter</SelectItem>
                      <SelectItem value="react">React</SelectItem>
                      <SelectItem value="vue">Vue.js</SelectItem>
                      <SelectItem value="angular">Angular</SelectItem>
                      <SelectItem value="nextjs">Next.js</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Button 
                  onClick={handleCreateProject} 
                  className="w-full"
                  disabled={createProjectMutation.isPending}
                >
                  {createProjectMutation.isPending ? "Creating..." : "Create Project"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
        
        <div className="space-y-2">
          {projects.map((project) => (
            <Card
              key={project.id}
              className={`cursor-pointer transition-all ${
                currentProject?.id === project.id
                  ? "bg-sidebar-accent border-sidebar-primary"
                  : "hover:bg-sidebar-accent/50"
              }`}
              onClick={() => setCurrentProject(project)}
            >
              <CardContent className="p-3">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-medium text-sidebar-foreground truncate">
                    {project.title}
                  </span>
                  <Badge className={getProjectStatusColor(project)}>
                    {getStatusText(project)}
                  </Badge>
                </div>
                {project.framework && (
                  <p className="text-xs text-sidebar-foreground/60">
                    {project.framework} project
                  </p>
                )}
              </CardContent>
            </Card>
          ))}
          
          {projects.length === 0 && (
            <div className="text-center py-8">
              <p className="text-sm text-sidebar-foreground/60 mb-3">No projects yet</p>
              <Button size="sm" onClick={() => setNewProjectOpen(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Create your first project
              </Button>
            </div>
          )}
        </div>
      </div>

      {/* API Limits */}
      <div className="p-4 border-t border-sidebar-border">
        <h4 className="text-xs font-medium text-sidebar-foreground/60 uppercase tracking-wider mb-2">
          API Usage Today
        </h4>
        
        {apiUsage ? (
          <div className="space-y-3">
            <div>
              <div className="flex justify-between items-center text-sm mb-1">
                <span className="text-sidebar-foreground/80">Planning AI</span>
                <span className="font-medium text-sidebar-foreground">
                  {apiUsage.planning.used}/{apiUsage.planning.limit}
                </span>
              </div>
              <Progress 
                value={(apiUsage.planning.used / apiUsage.planning.limit) * 100} 
                className="h-1.5"
              />
            </div>
            
            <div>
              <div className="flex justify-between items-center text-sm mb-1">
                <span className="text-sidebar-foreground/80">Dev AI</span>
                <span className="font-medium text-sidebar-foreground">
                  {apiUsage.development.used}/{apiUsage.development.limit}
                </span>
              </div>
              <Progress 
                value={(apiUsage.development.used / apiUsage.development.limit) * 100} 
                className="h-1.5"
              />
            </div>
          </div>
        ) : (
          <div className="space-y-2">
            <div className="h-4 bg-sidebar-accent rounded animate-pulse" />
            <div className="h-4 bg-sidebar-accent rounded animate-pulse" />
          </div>
        )}
        
        {/* Settings & Logout */}
        <div className="flex items-center justify-between mt-4 pt-3 border-t border-sidebar-border">
          <Button variant="ghost" size="sm">
            <Settings className="w-4 h-4" />
          </Button>
          <Button 
            variant="ghost" 
            size="sm"
            onClick={() => window.location.href = "/api/logout"}
          >
            <LogOut className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </aside>
  );
}
