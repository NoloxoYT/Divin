import { useState, useEffect, useRef } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useProject } from "@/contexts/ProjectContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { Bot, User, Send, AlertCircle } from "lucide-react";
import { cn } from "@/lib/utils";
import ReactMarkdown from 'react-markdown';

interface ChatMessage {
  role: "system" | "user" | "assistant";
  content: string;
  timestamp?: number;
}

export default function ChatInterface() {
  const { currentProject } = useProject();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [message, setMessage] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Fetch API usage for rate limiting display
  const { data: apiUsage } = useQuery({
    queryKey: ["/api/usage"],
    refetchInterval: 30000, // Refetch every 30 seconds
  });

  // Get current phase messages
  const messages = currentProject
    ? (currentProject.currentPhase === "planning" 
        ? currentProject.planningMessages 
        : currentProject.developmentMessages) as ChatMessage[] || []
    : [];

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async ({ message, projectId, phase }: { message: string; projectId: string; phase: string }) => {
      const response = await apiRequest("POST", "/api/chat", { message, projectId, phase });
      return response.json();
    },
    onSuccess: (data) => {
      // Refetch project to get updated messages
      queryClient.invalidateQueries({ queryKey: [`/api/projects/${currentProject?.id}`] });
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      queryClient.invalidateQueries({ queryKey: ["/api/usage"] });
      
      setMessage("");
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        alert("Seule la connexion OAuth (Google, GitHub, Apple) est disponible pour le moment.");
        return;
      }
      
      const errorMessage = error instanceof Error ? error.message : "Failed to send message";
      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive",
      });
    },
  });

  // Auto-scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSendMessage = () => {
    if (!message.trim() || !currentProject || sendMessageMutation.isPending) return;
    
    sendMessageMutation.mutate({
      message,
      projectId: currentProject.id,
      phase: currentProject.currentPhase,
    });
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const formatMessage = (content: string, role: string) => {
    if (role === "assistant") {
      return <ReactMarkdown>{content}</ReactMarkdown>;
    }
    // Simple markdown-like formatting for code blocks (pour l'utilisateur)
    const parts = content.split(/(```[\s\S]*?```)/g);
    return parts.map((part, index) => {
      if (part.startsWith("```") && part.endsWith("```")) {
        const code = part.slice(3, -3).trim();
        return (
          <div key={index} className="code-block rounded-lg p-4 my-3 overflow-x-auto">
            <pre className="text-sm">
              <code>{code}</code>
            </pre>
          </div>
        );
      }
      return <span key={index}>{part}</span>;
    });
  };

  const getAIModelName = () => {
    if (!currentProject) return "";
    return currentProject.currentPhase === "planning" 
      ? "Llama-3.1-8b-instant" 
      : "LLaMA 3.3 70B Instruct";
  };

  const getSpecialistType = () => {
    if (!currentProject) return "";
    return currentProject.currentPhase === "planning" 
      ? "Planning Specialist" 
      : "Development Specialist";
  };

  const getRemainingRequests = () => {
    if (!apiUsage || !currentProject) return 0;
    const phase = currentProject.currentPhase;
    if (phase === "planning") {
      return apiUsage.planning.limit - apiUsage.planning.used;
    } else {
      return apiUsage.development.limit - apiUsage.development.used;
    }
  };

  if (!currentProject) {
    return (
      <div className="flex-1 flex flex-col border-r border-border">
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <AlertCircle className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">No Project Selected</h3>
            <p className="text-muted-foreground">Create or select a project to start chatting with AI.</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col border-r border-border">
      {/* Chat Header */}
      <div className="p-4 border-b border-border bg-muted/30">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <Bot className="w-5 h-5 text-primary mr-2" />
            <span className="font-medium">{getAIModelName()}</span>
            <Badge 
              className={cn(
                "ml-2",
                currentProject.currentPhase === "planning" 
                  ? "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300"
                  : "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
              )}
            >
              {getSpecialistType()}
            </Badge>
          </div>
          <div className="text-sm text-muted-foreground">
            <span className="font-medium">{getRemainingRequests()}</span> requests remaining today
          </div>
        </div>
      </div>

      {/* Chat Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar">
        {messages.length === 0 && (
          <div className="flex justify-center">
            <Card className="max-w-md">
              <CardContent className="p-6 text-center">
                <Bot className="w-12 h-12 text-primary mx-auto mb-4" />
                <h3 className="font-semibold mb-2">Ready to help!</h3>
                <p className="text-sm text-muted-foreground">
                  I'm your {currentProject.currentPhase} AI assistant. How can I help you with your project?
                </p>
              </CardContent>
            </Card>
          </div>
        )}

        {messages.map((msg, index) => (
          <div
            key={index}
            className={cn(
              "flex items-start space-x-3 chat-message",
              msg.role === "user" ? "justify-end" : "justify-start"
            )}
          >
            {msg.role !== "user" && (
              <div className={cn(
                "w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0",
                msg.role === "system" ? "bg-muted" : "bg-primary"
              )}>
                {msg.role === "system" ? (
                  <AlertCircle className="w-4 h-4 text-muted-foreground" />
                ) : (
                  <Bot className="w-4 h-4 text-primary-foreground" />
                )}
              </div>
            )}

            <div className={cn(
              "flex-1",
              msg.role === "user" ? "flex justify-end" : ""
            )}>
              <div className={cn(
                "rounded-lg p-4 max-w-2xl",
                msg.role === "user" 
                  ? "bg-primary text-primary-foreground ml-12" 
                  : msg.role === "system"
                  ? "bg-muted/50 text-muted-foreground text-center text-sm"
                  : "bg-muted/30"
              )}>
                <div className="text-sm leading-relaxed">
                  {msg.role === "system" ? msg.content : formatMessage(msg.content, msg.role)}
                </div>
                {msg.timestamp && (
                  <div className={cn(
                    "text-xs mt-2",
                    msg.role === "user" 
                      ? "text-primary-foreground/70" 
                      : "text-muted-foreground"
                  )}>
                    {new Date(msg.timestamp).toLocaleTimeString()}
                  </div>
                )}
              </div>
            </div>

            {msg.role === "user" && (
              <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center flex-shrink-0">
                <User className="w-4 h-4 text-secondary-foreground" />
              </div>
            )}
          </div>
        ))}

        {sendMessageMutation.isPending && (
          <div className="flex items-start space-x-3">
            <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
              <Bot className="w-4 h-4 text-primary-foreground" />
            </div>
            <div className="flex-1">
              <div className="bg-muted/30 rounded-lg p-4">
                <div className="flex items-center space-x-2">
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 bg-primary rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: "0.1s" }}></div>
                    <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: "0.2s" }}></div>
                  </div>
                  <span className="text-sm text-muted-foreground">AI is thinking...</span>
                </div>
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Chat Input */}
      <div className="border-t border-border p-4">
        <div className="flex space-x-3">
          <Input
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder={`Ask about your project ${currentProject.currentPhase}...`}
            className="flex-1"
            disabled={sendMessageMutation.isPending || getRemainingRequests() <= 0}
          />
          <Button 
            onClick={handleSendMessage}
            disabled={!message.trim() || sendMessageMutation.isPending || getRemainingRequests() <= 0}
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
        <div className="flex items-center justify-between mt-2 text-xs text-muted-foreground">
          <span>
            {currentProject.currentPhase === "planning" ? "Planning" : "Development"} AI active • {getRemainingRequests()} requests remaining
          </span>
          <span>Press Enter to send</span>
        </div>
      </div>
    </div>
  );
}
