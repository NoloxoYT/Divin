import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { Brain, Code } from "lucide-react";

interface PhaseIndicatorProps {
  phase: "planning" | "development";
  className?: string;
}

export default function PhaseIndicator({ phase, className }: PhaseIndicatorProps) {
  const isPlanning = phase === "planning";
  
  return (
    <div className={cn("flex items-center", className)}>
      <Badge 
        className={cn(
          "flex items-center space-x-2 px-3 py-1 phase-indicator",
          isPlanning 
            ? "bg-blue-100 text-blue-800 hover:bg-blue-200 dark:bg-blue-900 dark:text-blue-300 dark:hover:bg-blue-800" 
            : "bg-green-100 text-green-800 hover:bg-green-200 dark:bg-green-900 dark:text-green-300 dark:hover:bg-green-800"
        )}
      >
        <div className={cn(
          "w-2 h-2 rounded-full",
          isPlanning ? "bg-blue-600 dark:bg-blue-400" : "bg-green-600 dark:bg-green-400"
        )} />
        {isPlanning ? <Brain className="w-3 h-3" /> : <Code className="w-3 h-3" />}
        <span className="font-medium">
          {isPlanning ? "Planning Phase" : "Development Phase"}
        </span>
      </Badge>
    </div>
  );
}
