import { useState } from "react";
import { useProject } from "@/contexts/ProjectContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { RefreshCw, ExternalLink, Smartphone, Tablet, Monitor, Rocket } from "lucide-react";
import { cn } from "@/lib/utils";

type ViewportType = "mobile" | "tablet" | "desktop";

export default function LivePreview() {
  const { currentProject } = useProject();
  const [viewport, setViewport] = useState<ViewportType>("mobile");
  const [isRefreshing, setIsRefreshing] = useState(false);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    // Simulate refresh delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    setIsRefreshing(false);
  };

  const getViewportIcon = (type: ViewportType) => {
    switch (type) {
      case "mobile": return <Smartphone className="w-4 h-4" />;
      case "tablet": return <Tablet className="w-4 h-4" />;
      case "desktop": return <Monitor className="w-4 h-4" />;
    }
  };

  const getPreviewContent = () => {
    if (!currentProject) {
      return (
        <div className="flex-1 flex items-center justify-center text-center p-8">
          <div>
            <Smartphone className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">No Project Selected</h3>
            <p className="text-muted-foreground">Select a project to see the live preview.</p>
          </div>
        </div>
      );
    }

    if (currentProject.currentPhase === "planning") {
      return (
        <div className="flex-1 flex items-center justify-center text-center p-8">
          <div>
            <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
              <Smartphone className="w-8 h-8 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-semibold mb-2">Planning Phase</h3>
            <p className="text-muted-foreground mb-4">Preview will be available once development starts.</p>
            <Badge variant="outline">Waiting for approved plan</Badge>
          </div>
        </div>
      );
    }

    // Mock preview content for development phase
    return (
      <div className="flex-1 flex items-center justify-center p-6">
        <div className="relative">
          {/* Device Frame */}
          <div className={cn(
            "bg-gray-900 rounded-3xl p-3 shadow-2xl preview-frame transition-all duration-300",
            viewport === "mobile" && "w-72 h-96",
            viewport === "tablet" && "w-80 h-[500px]",
            viewport === "desktop" && "w-96 h-[600px]"
          )}>
            <div className="w-full h-full bg-white rounded-2xl overflow-hidden relative">
              {/* Status Bar (mobile only) */}
              {viewport === "mobile" && (
                <div className="h-8 bg-gray-100 flex items-center justify-between px-4 text-xs font-medium">
                  <span>9:41</span>
                  <div className="flex items-center space-x-1 text-gray-600">
                    <div className="flex space-x-1">
                      <div className="w-1 h-3 bg-current rounded-full opacity-60"></div>
                      <div className="w-1 h-3 bg-current rounded-full opacity-80"></div>
                      <div className="w-1 h-3 bg-current rounded-full"></div>
                      <div className="w-1 h-3 bg-current rounded-full"></div>
                    </div>
                    <div className="w-4 h-2 border border-current rounded-sm">
                      <div className="w-3/4 h-full bg-current rounded-sm"></div>
                    </div>
                  </div>
                </div>
              )}
              
              {/* App Content */}
              <div className="flex-1 p-4">
                {/* App Header */}
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold text-gray-800">
                    {currentProject.title}
                  </h2>
                  <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center">
                    <span className="text-white text-lg">+</span>
                  </div>
                </div>
                
                {/* Sample Content */}
                <div className="space-y-3">
                  <div className="flex items-center p-3 bg-gray-50 rounded-lg">
                    <div className="w-5 h-5 border-2 border-gray-300 rounded mr-3"></div>
                    <span className="text-gray-700 text-sm flex-1">Sample item 1</span>
                  </div>
                  <div className="flex items-center p-3 bg-gray-50 rounded-lg">
                    <div className="w-5 h-5 bg-green-500 rounded mr-3 flex items-center justify-center">
                      <div className="w-2 h-1 border-l-2 border-b-2 border-white transform rotate-45"></div>
                    </div>
                    <span className="text-gray-400 text-sm line-through flex-1">Completed item</span>
                  </div>
                  <div className="flex items-center p-3 bg-gray-50 rounded-lg">
                    <div className="w-5 h-5 border-2 border-gray-300 rounded mr-3"></div>
                    <span className="text-gray-700 text-sm flex-1">Another item</span>
                  </div>
                </div>
                
                {/* Add Input */}
                <div className="mt-6">
                  <div className="flex items-center p-3 border border-gray-200 rounded-lg">
                    <input 
                      type="text" 
                      placeholder="Add new item..." 
                      className="flex-1 text-sm outline-none bg-transparent"
                      readOnly
                    />
                    <div className="w-6 h-6 bg-blue-500 rounded flex items-center justify-center ml-2">
                      <span className="text-white text-xs">+</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Home Indicator (mobile only) */}
            {viewport === "mobile" && (
              <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 w-32 h-1 bg-gray-700 rounded-full"></div>
            )}
          </div>
          
          {/* Preview Status */}
          <div className="absolute -bottom-8 left-0 right-0 text-center">
            <Badge variant="outline" className="text-xs">
              Live Preview • Auto-updating
            </Badge>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="w-1/3 min-w-80 flex flex-col bg-background">
      {/* Preview Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between">
          <h3 className="font-medium">Live Preview</h3>
          <div className="flex items-center space-x-2">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={handleRefresh}
              disabled={isRefreshing}
            >
              <RefreshCw className={cn("w-4 h-4", isRefreshing && "animate-spin")} />
            </Button>
            <Button variant="ghost" size="sm">
              <ExternalLink className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Preview Content */}
      {getPreviewContent()}

      {/* Preview Controls */}
      <div className="p-4 border-t border-border">
        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center space-x-4">
            <Button
              variant={viewport === "mobile" ? "default" : "ghost"}
              size="sm"
              onClick={() => setViewport("mobile")}
            >
              <Smartphone className="w-4 h-4 mr-2" />
              Mobile
            </Button>
            <Button
              variant={viewport === "tablet" ? "default" : "ghost"}
              size="sm"
              onClick={() => setViewport("tablet")}
            >
              <Tablet className="w-4 h-4 mr-2" />
              Tablet
            </Button>
          </div>
          <Button variant="outline" size="sm">
            <Rocket className="w-4 h-4 mr-2" />
            Deploy
          </Button>
        </div>
      </div>
    </div>
  );
}
