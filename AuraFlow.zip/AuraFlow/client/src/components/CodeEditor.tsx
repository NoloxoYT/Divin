import React, { useState, useRef } from 'react';
import Editor from '@monaco-editor/react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  FileText, 
  Folder, 
  Plus, 
  Trash2, 
  Save, 
  Play,
  Settings,
  Code
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface FileNode {
  id: string;
  name: string;
  type: 'file' | 'folder';
  content?: string;
  children?: FileNode[];
  language?: string;
}

interface CodeEditorProps {
  className?: string;
}

export default function CodeEditor({ className }: CodeEditorProps) {
  const [files, setFiles] = useState<FileNode[]>([
    {
      id: '1',
      name: 'main.js',
      type: 'file',
      content: 'console.log("Hello, World!");\n\nfunction greet(name) {\n  return `Hello, ${name}!`;\n}\n\ngreet("AuraFlow");',
      language: 'javascript'
    },
    {
      id: '2',
      name: 'styles.css',
      type: 'file',
      content: 'body {\n  font-family: Arial, sans-serif;\n  margin: 0;\n  padding: 20px;\n  background-color: #f5f5f5;\n}\n\n.container {\n  max-width: 1200px;\n  margin: 0 auto;\n}',
      language: 'css'
    },
    {
      id: '3',
      name: 'index.html',
      type: 'file',
      content: '<!DOCTYPE html>\n<html lang="en">\n<head>\n  <meta charset="UTF-8">\n  <meta name="viewport" content="width=device-width, initial-scale=1.0">\n  <title>AuraFlow</title>\n  <link rel="stylesheet" href="styles.css">\n</head>\n<body>\n  <div class="container">\n    <h1>Welcome to AuraFlow</h1>\n    <p>Your AI-powered development environment</p>\n  </div>\n  <script src="main.js"></script>\n</body>\n</html>',
      language: 'html'
    }
  ]);

  const [selectedFile, setSelectedFile] = useState<FileNode | null>(files[0]);
  const [newFileName, setNewFileName] = useState('');
  const [showNewFileInput, setShowNewFileInput] = useState(false);
  const editorRef = useRef<any>(null);

  const handleEditorDidMount = (editor: any) => {
    editorRef.current = editor;
  };

  const handleSave = () => {
    if (selectedFile && editorRef.current) {
      const content = editorRef.current.getValue();
      setFiles(prev => prev.map(file => 
        file.id === selectedFile.id 
          ? { ...file, content } 
          : file
      ));
    }
  };

  const handleRun = () => {
    if (selectedFile) {
      // Ici on pourra intégrer l'exécution avec GitHub Codespaces
      console.log('Running file:', selectedFile.name);
      console.log('Content:', selectedFile.content);
    }
  };

  const createNewFile = () => {
    if (newFileName.trim()) {
      const newFile: FileNode = {
        id: Date.now().toString(),
        name: newFileName,
        type: 'file',
        content: '',
        language: 'javascript'
      };
      setFiles(prev => [...prev, newFile]);
      setSelectedFile(newFile);
      setNewFileName('');
      setShowNewFileInput(false);
    }
  };

  const deleteFile = (fileId: string) => {
    setFiles(prev => prev.filter(file => file.id !== fileId));
    if (selectedFile?.id === fileId) {
      setSelectedFile(files[0] || null);
    }
  };

  const getLanguageFromFileName = (fileName: string) => {
    const ext = fileName.split('.').pop()?.toLowerCase();
    switch (ext) {
      case 'js': return 'javascript';
      case 'ts': return 'typescript';
      case 'html': return 'html';
      case 'css': return 'css';
      case 'json': return 'json';
      case 'py': return 'python';
      case 'java': return 'java';
      case 'cpp': return 'cpp';
      case 'c': return 'c';
      case 'php': return 'php';
      case 'rb': return 'ruby';
      case 'go': return 'go';
      case 'rs': return 'rust';
      default: return 'javascript';
    }
  };

  return (
    <div className={cn("flex h-full", className)}>
      {/* Sidebar - File Explorer */}
      <div className="w-64 bg-muted/30 border-r border-border">
        <div className="p-4 border-b border-border">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-sm">Files</h3>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => setShowNewFileInput(true)}
            >
              <Plus className="w-4 h-4" />
            </Button>
          </div>
          
          {showNewFileInput && (
            <div className="flex gap-2 mb-4">
              <Input
                size={1}
                value={newFileName}
                onChange={(e) => setNewFileName(e.target.value)}
                placeholder="filename.js"
                onKeyPress={(e) => e.key === 'Enter' && createNewFile()}
              />
              <Button size="sm" onClick={createNewFile}>
                <Plus className="w-4 h-4" />
              </Button>
            </div>
          )}
        </div>

        <div className="p-2">
          {files.map((file) => (
            <div
              key={file.id}
              className={cn(
                "flex items-center justify-between p-2 rounded-md cursor-pointer hover:bg-muted/50",
                selectedFile?.id === file.id && "bg-muted"
              )}
              onClick={() => setSelectedFile(file)}
            >
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4" />
                <span className="text-sm">{file.name}</span>
              </div>
              <Button
                size="sm"
                variant="ghost"
                onClick={(e) => {
                  e.stopPropagation();
                  deleteFile(file.id);
                }}
              >
                <Trash2 className="w-3 h-3" />
              </Button>
            </div>
          ))}
        </div>
      </div>

      {/* Main Editor Area */}
      <div className="flex-1 flex flex-col">
        {/* Toolbar */}
        <div className="flex items-center justify-between p-4 border-b border-border bg-background">
          <div className="flex items-center gap-2">
            <Code className="w-5 h-5" />
            <span className="font-medium">
              {selectedFile?.name || 'No file selected'}
            </span>
          </div>
          
          <div className="flex items-center gap-2">
            <Button size="sm" variant="outline" onClick={handleSave}>
              <Save className="w-4 h-4 mr-2" />
              Save
            </Button>
            <Button size="sm" onClick={handleRun}>
              <Play className="w-4 h-4 mr-2" />
              Run
            </Button>
            <Button size="sm" variant="ghost">
              <Settings className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Monaco Editor */}
        <div className="flex-1">
          {selectedFile ? (
            <Editor
              height="100%"
              defaultLanguage={getLanguageFromFileName(selectedFile.name)}
              defaultValue={selectedFile.content || ''}
              theme="vs-dark"
              onMount={handleEditorDidMount}
              options={{
                minimap: { enabled: true },
                fontSize: 14,
                wordWrap: 'on',
                automaticLayout: true,
                scrollBeyondLastLine: false,
                roundedSelection: false,
                readOnly: false,
                cursorStyle: 'line',
              }}
            />
          ) : (
            <div className="flex items-center justify-center h-full text-muted-foreground">
              <div className="text-center">
                <FileText className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>Select a file to start editing</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
