import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useProject } from "@/contexts/ProjectContext";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import Sidebar from "@/components/Sidebar";
import TopBar from "@/components/TopBar";
import ChatInterface from "@/components/ChatInterface";
import LivePreview from "@/components/LivePreview";
import CodeEditor from '@/components/CodeEditor';
import { Skeleton } from "@/components/ui/skeleton";

export default function Home() {
  const { isAuthenticated, isLoading } = useAuth();
  const { currentProject, setCurrentProject, setProjects } = useProject();
  const { toast } = useToast();

  // Fetch projects
  const { data: projects, isLoading: projectsLoading } = useQuery({
    queryKey: ["/api/projects"],
    retry: false,
  });

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      alert("Seule la connexion OAuth (Google, GitHub, Apple) est disponible pour le moment.");
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  // Set projects when loaded
  useEffect(() => {
    if (projects) {
      setProjects(projects);
      
      // Set current project to first active project if none selected
      if (!currentProject && projects.length > 0) {
        const activeProject = projects.find((p: any) => p.status === "active") || projects[0];
        setCurrentProject(activeProject);
      }
    }
  }, [projects, currentProject, setProjects, setCurrentProject]);

  if (isLoading || projectsLoading) {
    return (
      <div className="flex h-screen">
        <div className="w-64 border-r">
          <Skeleton className="h-full" />
        </div>
        <div className="flex-1 flex flex-col">
          <div className="h-14 border-b">
            <Skeleton className="h-full" />
          </div>
          <div className="flex-1 flex">
            <div className="flex-1">
              <Skeleton className="h-full" />
            </div>
            <div className="w-1/3">
              <Skeleton className="h-full" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null; // Will redirect to login
  }

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      
      <div className="flex-1 flex flex-col">
        <TopBar />
        
        <div className="flex-1 flex overflow-hidden">
          <ChatInterface />
          <LivePreview />
          <CodeEditor className="flex-1" />
        </div>
      </div>
    </div>
  );
}
