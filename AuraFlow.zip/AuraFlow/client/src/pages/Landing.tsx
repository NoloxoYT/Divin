import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Github, Mail, Bot, Zap, Code, Smartphone, Chrome } from "lucide-react";

export default function Landing() {
  const handleAuth = (provider: string) => {
    if (provider === "github") {
      window.location.href = "/api/auth/github";
    } else if (provider === "google") {
      window.location.href = "/api/auth/google";
    } else if (provider === "email") {
      alert("Seule la connexion OAuth (Google, GitHub) est disponible pour le moment.");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/20">
      {/* Hero Section */}
      <div className="container mx-auto px-4 py-16">
        <div className="text-center mb-16">
          <div className="flex items-center justify-center mb-6">
            <div className="w-16 h-16 bg-primary rounded-lg flex items-center justify-center mr-4">
              <Bot className="w-8 h-8 text-primary-foreground" />
            </div>
            <h1 className="text-4xl font-bold">AI Dev Workflow</h1>
          </div>
          
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Build mobile and web applications faster with our AI-powered development workflow. 
            From planning to deployment, let AI guide your development journey.
          </p>

          {/* Features Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
            <Card className="p-6">
              <CardContent className="p-0">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4 mx-auto">
                  <Zap className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-lg font-semibold mb-2">AI-Powered Planning</h3>
                <p className="text-muted-foreground text-sm">
                  Get comprehensive project plans and architecture recommendations from specialized AI.
                </p>
              </CardContent>
            </Card>

            <Card className="p-6">
              <CardContent className="p-0">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4 mx-auto">
                  <Code className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Smart Code Generation</h3>
                <p className="text-muted-foreground text-sm">
                  Transform approved plans into production-ready code with intelligent development AI.
                </p>
              </CardContent>
            </Card>

            <Card className="p-6">
              <CardContent className="p-0">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4 mx-auto">
                  <Smartphone className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Live Preview</h3>
                <p className="text-muted-foreground text-sm">
                  See your mobile and web apps come to life with real-time preview capabilities.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Auth Section */}
        <Card className="max-w-md mx-auto">
          <CardContent className="p-8">
            <h2 className="text-2xl font-semibold text-center mb-2">Get Started</h2>
            <p className="text-center text-muted-foreground mb-6">
              Choose your preferred sign-in method
            </p>

            <div className="space-y-3">
              <Button
                onClick={() => handleAuth("github")}
                variant="outline"
                size="lg"
                className="w-full"
              >
                <Github className="w-5 h-5 mr-3" />
                Continue with GitHub
              </Button>

              <Button
                onClick={() => handleAuth("google")}
                variant="outline"
                size="lg"
                className="w-full"
              >
                <Chrome className="w-5 h-5 mr-3" />
                Continue with Google
              </Button>

              <div className="relative my-4">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-background px-2 text-muted-foreground">or</span>
                </div>
              </div>

              <Button
                onClick={() => handleAuth("email")}
                size="lg"
                className="w-full"
              >
                <Mail className="w-5 h-5 mr-3" />
                Continue with Email
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
